clear all; close all

set(groot,'DefaultAxesFontSize',14)
set(groot,'DefaultLineLineWidth',2)
set(groot,'DefaultFunctionLineLineWidth',2)
set(groot,'DefaultTextInterpreter','latex')
set(groot,'DefaultAxesTickLabelInterpreter','latex')
set(groot,'DefaultLegendInterpreter','latex');


load Label.mat
load Performance.mat

Team=Label;
A=Performance;

Rating = ColleySolve(A);

[Rating, I] = sort(Rating);
Team        = Team(I);

T=table(Team,Rating)

%%

%Get percentiles
p      = [ 10, 25, 50, 75, 90 ];
P      = prctile( Rating, p );

for k = 1:numel(p)
    IP(k)     = find( Rating >= P(k), 1)
end

%%
barh(Rating)
ax = gca;
set(ax, 'YTickLabel',Team, 'YTick',1:numel(Team), 'FontSize', 4)
set(ax, 'Xgrid', 'on')
xlabel('Team Rating', 'FontSize', 14 )
title('March Maddness 2017', 'FontSize', 15)

hold on
    for k = 1:numel(p)
        STRARG = [num2str(p(k)), '$^{th}$ pctile'];
        plot(  [0,1], (IP(k)-0.5)*[1,1], '--k'  )
        text( 0.75,   IP(k)+0.2,   STRARG )
    end
hold off