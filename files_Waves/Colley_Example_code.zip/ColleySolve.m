function [ Rating ] = ColleySolve( A )
%Gives team rating based on the colley method
%A is a matrix of results
%of the form: Row beats column

s=size(A); 
if ~(s(1)==s(2))
    disp('Error: argument needs to be a square matrix.')
    return;
end
s(2)=[];
for j=1:s
    if A(s,s) ~=0
        disp('Error: argument does not have zeros on all diagonals.')
    end
end

C=zeros(s,s);
b=zeros(s,1);
for i=1:s
    w=sum(A(i,:));
    l=sum(A(:,i));
    t=w+l;
    b(i)=1+(w-l)/2;
    C(i,i)=t+2;
    for j=1:s
        if ~(i==j)
        C(i,j)=-(A(i,j)+A(j,i));
        end
    end
end
Rating=C\b;

end

