#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 22 18:42:21 2025

@author: nick
"""


import numpy as np
import BlackScholesFunctions as bsf
import matplotlib.pyplot as plt

def surface_plot( x, y, z ):
    fig = plt.figure()
    ax = fig.add_subplot( 111, projection='3d')

    surf = ax.plot_surface( x, y, z 
                          #, cmap
                          , antialiased=True,
                          #, alpha
                          )

    #cbar = fig.colorbar(surf)
    ax.view_init(elev=20, azim=135)
    return ax


# time to expiry and moneyness
N1 = 30
N2 = 31
t = np.linspace( 0.1, 1.0, N1 )
m = np.linspace( 0.1, 2.5, N2 )

[T,M] = np.meshgrid( t, m )

# cnst Params
sigma_real = 0.2
S = 100.0
r = 0.05

# Noise Parameter
def noise( N1=1, N2=1, noise_param = 0.01 ): 
    return (1 + 2.0*noise_param*( np.random.rand(N1,N2)-0.5 ) )

sigma_real = sigma_real * np.ones( M.shape )# noise( M.shape[0], M.shape[1] )

# Call option prices estimated with black scholes
C = 0.0 * M
for i in range(N2):
    for j in range(N1):
        C[i,j] = bsf.call_option_price( S*noise(), S/M[i,j], T[i,j], r, sigma_real[i,j]*noise(), q=0 )
        C[i,j] *= noise()


ax = surface_plot( M, T, C )

ax.set_zlim([0,S])

ax.set_xlabel("Moneyness (S/K)")
ax.set_ylabel("Time to Expiration [yr]")
ax.set_zlabel("C price")
ax.set_title("C Price BS model")

plt.show()


# implied volatility
iv = 0.0*C
for i in range(N2):
    for j in range(N1):
        if( i==0 and j==0 ):
            iv[i,j] = bsf.solve_for_iv( C[i,j], S, S/M[i,j], T[i,j], r, \
                    ftolerance=0.0005 , sigma_guess=1.0, verbose=True   )
        else:
            iv[i,j] = bsf.solve_for_iv( C[i,j], S, S/M[i,j], T[i,j], r, \
                    ftolerance=0.0005 , sigma_guess=1.0, verbose=False   )

print( "count iv computed nans: ", sum( np.isnan( iv.flatten() ) ) )
        
ax = surface_plot( M, T, iv )

ax.set_zlim([0,2.5])

ax.set_xlabel("Moneyness (S/K)")
ax.set_ylabel("Time to Expiration [yr]")
ax.set_zlabel("implied volatility")

plt.show()
        
        
        
