#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import pandas as pd
import numpy as np

import BlackScholesFunctions as BSF
from BlackScholesFunctions import solve_for_iv
#from OptionsScraper import download_options_chain, todays_price #-- utilities from the yfinance package by Ran Aroussi

from matplotlib import pyplot as plt

# Example of an AAPL option
# from yfinance
S = 256.53
K = 110.0 
#K = 111
T = 0.005479452054794521 # = 0.010958904109589041 
r = 0.06
q = 0# 0.0041
sigma_real = 3.43750140625 
C_real = 146.72500000000002
C_real = 147.95

print("Example of soln for implied volatility:")
print("  system vars: S =",S,", K =",K,", T =",T,", r =",r,",")
print("      moneyness = ", S/K, ",  C envelope width Se^-qT - Ke^-rT =", S*np.exp(-q*T)-K*np.exp(-r*T) )
print("      sigma_real =",sigma_real,", C_real =",C_real)
print("")
C = BSF.call_option_price( S, K, T, r, sigma_real, q=q )
print("Given implied volatility from yfinance, the BS price would be C =", C )

print("")
print("iteratively solve for sigma: ")
sigma = solve_for_iv( C_real, S, K, T, r, q=q, sigma_guess = 8.8, verbose = True )
print("final error in sigma = ", abs( sigma-sigma_real ) )


BSF.show_iv_solution_on_graph(  C_real, S, K, T, r, sigma, q=q, smax=5)