#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 16 21:39:35 2025

@author: nick
"""
import numpy as np
from scipy.stats import norm 

#------------------------------------------------------------
def call_option_price( S, K, T, r, sigma, q=0 ):
    if T==0:
        C = max(S-K,0)
        return C
    if sigma == 0:
        C = max( S * np.exp(-q*T) - K *np.exp(-r*T) , 0 )
        return C 
    
    d1 =( np.log(S/K) + ( r - q + 0.5 * sigma**2 ) * T )/( sigma*np.sqrt(T) ) 
    d2 = d1 - sigma*np.sqrt(T)
    
    C = S * np.exp(-q*T) * norm.cdf( d1, 0,1 ) - K *np.exp(-r*T) * norm.cdf( d2, 0, 1 )
        
    return C
#------------------------------------------------------------

#------------------------------------------------------------
def call_dC_ds( S, K, T, r, sigma, q=0 ):
    if T==0:
        dC_ds = 0
        return dC_ds
    
    d1 =( np.log(S/K) + ( r - q + 0.5 * sigma**2 ) * T )/( sigma*np.sqrt(T) ) 
    d2 = d1 - sigma*np.sqrt(T)
    dd1 = np.sqrt(T) - d1 / sigma
    dd2 = dd1 - np.sqrt(T)
    
    dC_ds = S * np.exp(-q*T)  * dd1 * norm.pdf( d1, 0,1 )  \
            - K *np.exp(-r*T) * dd2 * norm.pdf( d2, 0, 1 )
        
    return dC_ds
#------------------------------------------------------------


#------------------------------------------------------------
def loss_fn( C, S, K, T, r, sigma, q=0, verbose=False ):
    
    # if verbose:
    #     d1 =( np.log(S/K) + ( r - q + 0.5 * sigma**2 ) * T )/( sigma*np.sqrt(T) ) 
    #    d2 = d1 - sigma*np.sqrt(T)
    #    print("d1 =", d1, ", d2 =", d2 )
    return ( call_option_price( S, K, T, r, sigma, q) - C  )

def loss_grad_fn( C, S, K, T, r, sigma, q=0,  epsilon=0.0005):
    f = lambda ss: loss_fn( C, S, K, T, r, ss, q )
    return ( f(sigma+epsilon) - f(sigma) )/( epsilon )
    #return -call_dC_ds( S, K, T, r, sigma, q )
#------------------------------------------------------------


#------------------------------------------------------------
def discover_guess( f , dx, upper_loss_thresh ):
    
    upper_search_lim = 30.0
    nosecondary = True
    
    x_m = 0.001
    x0 = 0.001
    y0 = f(x0)
    x = x0
    
    while (x<upper_search_lim):
        x = x + dx
        y = f(x)
        
        if nosecondary:
            if ( y < upper_loss_thresh ):
                x_m = x
                nosecondary = False
            
        if ( y*y0 <= 0 ):
            x = (x+x0)/2.0
            return x
        else:
            x0 = x
    
    if nosecondary: 
        return upper_search_lim
    else:
        return x_m
        
    
#------------------------------------------------------------


#------------------------------------------------------------
def solve_for_iv( C, S, K, T, r, sigma_guess=1.0, Niter=20, ftolerance=0.0005, q=0, verbose=False   ):
    
    if T==0:
        converged = True
        return np.nan
    
    converged = False
    sigma = sigma_guess
    
    f  = lambda sig: loss_fn( C, S, K, T, r, sig, q=q, verbose=verbose)
    df = lambda sig: loss_grad_fn( C, S, K, T, r, sig, q=q)
    
    # if guess is "wild" by this heuristic
    # spend some extra effort to refine it
    # upper_loss_thresh = 10.0
    # if abs( f(sigma) > upper_loss_thresh ):
    #     d_sig = 0.5
    #     if verbose:
    #         print("Loss greater than ", upper_loss_thresh, " refining initial guess")
    #     sigma = discover_guess( f, d_sig,upper_loss_thresh )
    
    # compute with newtons method
    for n in range(Niter):
        
        loss = f( sigma )
        
        if verbose:
            print("Itr ", n, ", f_loss =", loss, ", sigma = ", sigma )
            
        if abs(loss)<ftolerance:
            converged = True
            if verbose:
                print("Converged!")
            break
                
        else:
            loss_grad = df( sigma ) 
            
            if loss_grad == 0.0:
                # default to bisection
                if loss > 0:
                    sigma = sigma/2
                else:
                    sigma = sigma*2
            else:
                #Newton
                sigma0 = sigma - loss/loss_grad
            
            # default to bisection if falls below zero
            # or goes to infinity just double it
            if sigma0 < 0:
                sigma = sigma/2
            elif sigma0 == np.inf:
                sigma = 2*sigma
            else:
                sigma = sigma0
            
    #if converged:
    #    pass
    #else:
    #    print("did not converge in", Niter, "iterations. Final error delta_C =", loss )
        
    return sigma        
        
#------------------------------------------------------------

#------------------------------------------------------------
def show_iv_solution_on_graph(  C, S, K, T, r, sigma_soln, smax=-1, q=0  ):
    
    from matplotlib import pyplot as plt
    
    f = lambda sig: call_option_price( S, K, T, r, sig )
    
    smin = 0.0
    if smax == -1:
        smax = 100.0
        
    s = np.linspace(smin,smax,100)
    y = 0*s
    for i in range(len(s)):
        y[i] = f(s[i])

    plt.figure()
    plt.plot( s, y )
    plt.plot( [smin, smax], [C,C], '--' )
    plt.plot( sigma_soln, f(sigma_soln), 'o' )
    plt.xlabel("$\sigma$")
    plt.ylabel("$C_{BS}(\sigma)$")
    plt.show()
    

#------------------------------------------------------------


if __name__ == "__main__":
    
    #sigma_real = 8.8
    #S = 443.
    #K = 150.
    #T = 0.016438
    #r = 0.05
    #C = 375.9
    
    S = 254.665  
    K = 105.0 
    T = 0.030136986301369864 
    r = 0.05
    sigma_real = 1.0000000000000003e-05
    C = 123.325
    
    print( "error check when T=0 : " )
    print( "    C = " , call_option_price( S, K, 0.0, r, sigma_real ) )
    print( "    sigma_implied = " , solve_for_iv( C, S, K, 0.0, r, verbose = True ) )
    print(" ")
    
    print("Example of soln for implied volatility:")
    print("  system vars: S =",S,", K =",K,", T =",T,", r =",r,",")
    print("      sigma_real =",sigma_real,", C =",C)
    print("")
    print("iteratively solve for sigma: ")
    sigma = solve_for_iv( C, S, K, T, r, sigma_guess = 8.8, verbose = True )
    print("final error in sigma = ", abs( sigma-sigma_real ) )
    

    show_iv_solution_on_graph(  C, S, K, T, r, sigma )
    

