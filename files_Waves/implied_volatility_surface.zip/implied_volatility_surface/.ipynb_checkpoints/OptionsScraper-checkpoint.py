#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 19 16:14:41 2025

@author: nick
"""
import pandas as pd
import numpy as np
# from datetime import datetime
import yfinance as yf


def download_options_chain(symbol):
    
    tk = yf.Ticker(symbol)
    # Expiration dates
    exps = tk.options

    # Get options for each expiration
    options = pd.DataFrame()
    for e in exps:
        opt_e = tk.option_chain(e)
        tempframe = pd.concat( [opt_e.calls, opt_e.puts ] )
        tempframe['expirationDate'] = e
        options = pd.concat( [options, tempframe], ignore_index=True)

    # Bizarre error in yfinance that gives the wrong expiration date
    # Add 1 day to get the correct expiration date
    options['expirationDate'] = pd.to_datetime(options['expirationDate']) + pd.Timedelta(days = 1)
    options['dte'] = options['expirationDate'].map( lambda x: (x - pd.Timestamp.today()).days / 365 )
    
    # Boolean column if the option is a CALL
    options['CALL'] = options['contractSymbol'].str[4:].apply(
        lambda x: "C" in x)
    
    options[['bid', 'ask', 'strike']] = options[['bid', 'ask', 'strike']].apply(pd.to_numeric)
    options['mark'] = (options['bid'] + options['ask']) / 2 # Calculate the midpoint of the bid-ask
    
    # Drop unnecessary and meaningless columns
    options = options.drop(columns = ['contractSize', 'currency', 'change', 'percentChange', 'lastTradeDate', 'lastPrice'])

    return options

def todays_price( symbol ):
    # for example just take the open price 
    tk = yf.Ticker(symbol)
    stockprice = tk.info['open']
    return stockprice
    
#def dividend_rate( symbol ):
#    return symbol

if __name__ == "__main__":
    
    symbol = "AAPL"
    stock_price = todays_price(symbol)
    options_chain = download_options_chain(symbol)    
    
    print("Testing yfinance functionality: ")
    print("todays price of", symbol," is $", stock_price)
    print("")
    print("Options chain on", symbol, ":  ")
    print( options_chain.head() )
    